package com.codingdojo.JavaExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
