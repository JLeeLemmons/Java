package com.codingdojo.loginreg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAndRegApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginAndRegApplication.class, args);
	}

}
