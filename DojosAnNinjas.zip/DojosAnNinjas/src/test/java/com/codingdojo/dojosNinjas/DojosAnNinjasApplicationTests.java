package com.codingdojo.dojosNinjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosAnNinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
